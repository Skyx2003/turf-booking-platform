
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';
import { Trophy, Mail, Lock, ArrowRight, User as UserIcon, Building2, Shield } from 'lucide-react';

const Auth: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [role, setRole] = useState<UserRole>('USER');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useApp();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(email || (isLogin ? 'user@example.com' : 'new@example.com'), role);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-[90vh] flex items-center justify-center p-4">
      <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-2 bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-slate-200">
        
        {/* Left Side: Illustration & Branding */}
        <div className="hidden lg:flex flex-col justify-between p-16 bg-slate-900 text-white relative overflow-hidden">
           <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-600/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
           <div className="relative z-10">
             <div className="flex items-center gap-2 mb-12">
                <div className="bg-emerald-600 p-2 rounded-xl">
                  <Trophy size={28} />
                </div>
                <span className="text-3xl font-black font-heading tracking-tight">TurfSync</span>
             </div>
             <h2 className="text-5xl font-black font-heading leading-tight mb-8">
               Step onto the <span className="text-emerald-500">Perfect Pitch.</span>
             </h2>
             <p className="text-slate-400 text-xl max-w-sm leading-relaxed">
               The easiest way to book sports facilities. Join thousands of athletes today.
             </p>
           </div>

           <div className="relative z-10 space-y-6">
             <div className="flex items-center gap-4 bg-white/5 p-6 rounded-3xl border border-white/10 backdrop-blur-sm">
                <div className="w-12 h-12 bg-emerald-500/20 rounded-2xl flex items-center justify-center text-emerald-500">
                  <Shield size={24} />
                </div>
                <div>
                  <p className="font-bold">Safe & Secure</p>
                  <p className="text-sm text-slate-400">Verified arenas & payment</p>
                </div>
             </div>
             <p className="text-slate-500 text-sm font-medium">© 2024 TurfSync Inc. All rights reserved.</p>
           </div>
        </div>

        {/* Right Side: Form */}
        <div className="p-8 md:p-16">
          <div className="max-w-md mx-auto space-y-8">
            <div>
              <h3 className="text-4xl font-black text-slate-900 font-heading mb-2">
                {isLogin ? 'Welcome Back' : 'Create Account'}
              </h3>
              <p className="text-slate-500 font-medium">
                {isLogin ? "It's game time. Access your dashboard." : "Join the squad and start booking elite turfs."}
              </p>
            </div>

            {/* Role Selector */}
            <div className="grid grid-cols-3 gap-3">
               {[
                 { id: 'USER', label: 'Player', icon: <UserIcon size={16} /> },
                 { id: 'OWNER', label: 'Owner', icon: <Building2 size={16} /> },
                 { id: 'ADMIN', label: 'Admin', icon: <Shield size={16} /> }
               ].map(r => (
                 <button 
                  key={r.id}
                  onClick={() => setRole(r.id as UserRole)}
                  className={`flex flex-col items-center gap-2 py-4 rounded-2xl border transition-all ${
                    role === r.id 
                    ? 'bg-emerald-600 border-emerald-600 text-white shadow-lg shadow-emerald-200' 
                    : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-white'
                  }`}
                 >
                   {r.icon}
                   <span className="text-xs font-black uppercase tracking-wider">{r.label}</span>
                 </button>
               ))}
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div className="relative group">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-600 transition-colors" size={20} />
                  <input 
                    type="email" 
                    placeholder="Email address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-medium"
                  />
                </div>
                <div className="relative group">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-600 transition-colors" size={20} />
                  <input 
                    type="password" 
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-medium"
                  />
                </div>
              </div>

              {isLogin && (
                <div className="flex justify-end">
                  <button type="button" className="text-sm font-bold text-emerald-600 hover:underline">Forgot Password?</button>
                </div>
              )}

              <button 
                type="submit"
                className="w-full py-5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xl rounded-2xl shadow-xl shadow-emerald-200 transition-all flex items-center justify-center gap-3"
              >
                {isLogin ? 'Sign In' : 'Join Now'} <ArrowRight size={24} />
              </button>
            </form>

            <div className="text-center pt-8">
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="text-slate-500 font-bold hover:text-emerald-600 transition-colors"
              >
                {isLogin ? "Don't have an account? Sign Up" : "Already have an account? Sign In"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Auth;
