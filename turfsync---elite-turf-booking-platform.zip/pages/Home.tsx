
import React from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import TurfCard from '../components/TurfCard';
import { 
  ShieldCheck, 
  Zap, 
  MapPin, 
  Users, 
  CheckCircle,
  PlayCircle,
  ArrowRight
} from 'lucide-react';

const Home: React.FC = () => {
  const { turfs } = useApp();

  return (
    <div className="space-y-20">
      {/* Hero Section */}
      <section className="relative h-[85vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&q=80&w=2000" 
            alt="Football Pitch"
            className="w-full h-full object-cover brightness-[0.4]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 to-transparent"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <div className="max-w-3xl space-y-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 font-semibold text-sm">
              <Zap size={16} />
              <span>Real-time availability in your city</span>
            </div>
            <h1 className="text-6xl md:text-8xl font-black font-heading leading-none">
              Book Your <br />
              <span className="text-emerald-500 italic">Perfect Play.</span>
            </h1>
            <p className="text-xl text-slate-300 leading-relaxed max-w-xl">
              From competitive matches to friendly weekend kicks, find and book elite sports turfs in seconds. The game starts here.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/search" className="px-8 py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-lg rounded-2xl shadow-xl shadow-emerald-900/40 transition-all flex items-center gap-2">
                Find Turfs Near You <ArrowRight size={20} />
              </Link>
              <button className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-bold text-lg rounded-2xl backdrop-blur-md border border-white/10 transition-all flex items-center gap-2">
                <PlayCircle size={20} /> Watch Demo
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="max-w-7xl mx-auto px-4 -mt-24 relative z-20">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Verified Turfs', val: '500+', icon: <CheckCircle className="text-emerald-500" /> },
            { label: 'Active Users', val: '12k', icon: <Users className="text-emerald-500" /> },
            { label: 'Daily Bookings', val: '2.5k', icon: <Zap className="text-emerald-500" /> },
            { label: 'Cities Covered', val: '45', icon: <MapPin className="text-emerald-500" /> },
          ].map((stat, i) => (
            <div key={i} className="bg-white p-6 rounded-3xl shadow-xl border border-slate-100 flex items-center gap-4">
              <div className="p-3 bg-emerald-50 rounded-2xl">
                {stat.icon}
              </div>
              <div>
                <p className="text-3xl font-black text-slate-800">{stat.val}</p>
                <p className="text-sm text-slate-500 font-medium">{stat.label}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Turfs */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-4xl font-black text-slate-900 font-heading mb-4">Elite Arenas</h2>
            <p className="text-slate-500 max-w-lg text-lg">Hand-picked premium turfs with professional facilities and top-rated maintenance.</p>
          </div>
          <Link to="/search" className="hidden md:flex items-center gap-2 text-emerald-600 font-bold hover:underline">
            View All Venues <ArrowRight size={18} />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {turfs.slice(0, 3).map(turf => (
            <TurfCard key={turf.id} turf={turf} />
          ))}
        </div>
      </section>

      {/* Why Us Section */}
      <section className="bg-slate-900 py-24 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-4xl md:text-5xl font-black font-heading mb-6">Built for the <span className="text-emerald-500">Modern Athlete</span></h2>
            <p className="text-slate-400 text-lg">We've removed the hassle of calls and uncertainty. Pure sport, simplified.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                title: 'Instant Confirmation',
                desc: 'No more "let me check and call you back." Real-time slots, instant confirmation emails.',
                icon: <Zap size={32} className="text-emerald-500" />
              },
              {
                title: 'Secure Payments',
                desc: 'Industry-standard encryption for all transactions. Hassle-free refunds if rules are met.',
                icon: <ShieldCheck size={32} className="text-emerald-500" />
              },
              {
                title: 'Verified Reviews',
                desc: 'See real photos and read honest feedback from players like you before you book.',
                icon: <Users size={32} className="text-emerald-500" />
              }
            ].map((item, i) => (
              <div key={i} className="group p-8 rounded-3xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all">
                <div className="mb-6 p-4 bg-emerald-500/10 rounded-2xl w-fit group-hover:scale-110 transition-transform">
                  {item.icon}
                </div>
                <h3 className="text-2xl font-bold mb-4">{item.title}</h3>
                <p className="text-slate-400 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 mb-24">
        <div className="relative rounded-[3rem] bg-emerald-600 p-12 md:p-24 overflow-hidden shadow-2xl shadow-emerald-200">
           <img 
            src="https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&q=80&w=2000" 
            alt="Pitch"
            className="absolute inset-0 w-full h-full object-cover mix-blend-overlay opacity-20"
          />
          <div className="relative z-10 text-center text-white max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-6xl font-black font-heading mb-8">Own a Sports Facility?</h2>
            <p className="text-xl text-emerald-50 text-emerald-100 mb-12">Join our network of elite turf owners and manage your bookings with professional tools.</p>
            <Link to="/auth" className="px-12 py-5 bg-white text-emerald-700 font-black text-xl rounded-2xl hover:bg-emerald-50 transition-colors inline-block shadow-lg">
              Register Your Turf Today
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
