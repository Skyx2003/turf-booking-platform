
import React from 'react';
import { useApp } from '../context/AppContext';
import { Navigate } from 'react-router-dom';
import UserDashboard from '../components/UserDashboard';
import OwnerDashboard from '../components/OwnerDashboard';
import AdminDashboard from '../components/AdminDashboard';

const Dashboard: React.FC = () => {
  const { currentUser } = useApp();

  if (!currentUser) return <Navigate to="/auth" />;

  switch (currentUser.role) {
    case 'ADMIN':
      return <AdminDashboard />;
    case 'OWNER':
      return <OwnerDashboard />;
    case 'USER':
    default:
      return <UserDashboard />;
  }
};

export default Dashboard;
