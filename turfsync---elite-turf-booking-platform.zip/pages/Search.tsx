
import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import TurfCard from '../components/TurfCard';
import { Search as SearchIcon, Filter, SlidersHorizontal, MapPin, X } from 'lucide-react';

const Search: React.FC = () => {
  const { turfs } = useApp();
  const [query, setQuery] = useState('');
  const [priceRange, setPriceRange] = useState(100);
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);

  const allAmenities = useMemo(() => {
    const set = new Set<string>();
    turfs.forEach(t => t.amenities.forEach(a => set.add(a)));
    return Array.from(set);
  }, [turfs]);

  const filteredTurfs = useMemo(() => {
    return turfs.filter(t => {
      const matchesQuery = t.name.toLowerCase().includes(query.toLowerCase()) || 
                          t.location.toLowerCase().includes(query.toLowerCase());
      const matchesPrice = t.pricePerHour <= priceRange;
      const matchesAmenities = selectedAmenities.length === 0 || 
                               selectedAmenities.every(a => t.amenities.includes(a));
      return matchesQuery && matchesPrice && matchesAmenities;
    });
  }, [turfs, query, priceRange, selectedAmenities]);

  const toggleAmenity = (a: string) => {
    setSelectedAmenities(prev => 
      prev.includes(a) ? prev.filter(x => x !== a) : [...prev, a]
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Filters Sidebar */}
        <aside className="w-full md:w-72 space-y-8 shrink-0">
          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-sm sticky top-24">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-black font-heading flex items-center gap-2">
                <SlidersHorizontal size={20} className="text-emerald-600" /> Filters
              </h2>
              {(selectedAmenities.length > 0 || query !== '' || priceRange !== 100) && (
                <button 
                  onClick={() => {
                    setQuery('');
                    setPriceRange(100);
                    setSelectedAmenities([]);
                  }}
                  className="text-xs font-bold text-red-500 hover:text-red-600 flex items-center gap-1"
                >
                  <X size={14} /> Reset
                </button>
              )}
            </div>

            <div className="space-y-6">
              {/* Price Range */}
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-4">Max Price: ${priceRange}/hr</label>
                <input 
                  type="range" 
                  min="20" 
                  max="100" 
                  step="5"
                  value={priceRange}
                  onChange={(e) => setPriceRange(Number(e.target.value))}
                  className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                />
              </div>

              <hr className="border-slate-100" />

              {/* Amenities */}
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-4">Amenities</label>
                <div className="space-y-3">
                  {allAmenities.map(a => (
                    <label key={a} className="flex items-center gap-3 cursor-pointer group">
                      <div className="relative">
                        <input 
                          type="checkbox" 
                          checked={selectedAmenities.includes(a)}
                          onChange={() => toggleAmenity(a)}
                          className="peer sr-only"
                        />
                        <div className="w-5 h-5 border-2 border-slate-300 rounded-md peer-checked:bg-emerald-600 peer-checked:border-emerald-600 transition-all"></div>
                        <CheckIcon className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white scale-0 peer-checked:scale-100 transition-transform" />
                      </div>
                      <span className="text-sm font-medium text-slate-600 group-hover:text-slate-900">{a}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* Search Results */}
        <div className="flex-grow space-y-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow group">
              <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-600 transition-colors" size={20} />
              <input 
                type="text" 
                placeholder="Search by turf name or location..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl shadow-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-medium"
              />
            </div>
            <button className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-8 py-4 rounded-2xl shadow-lg shadow-emerald-200 transition-all flex items-center justify-center gap-2">
              <MapPin size={20} /> Use Location
            </button>
          </div>

          <div className="flex items-center justify-between">
            <p className="text-slate-500 font-medium">Showing {filteredTurfs.length} results</p>
            <div className="flex items-center gap-2 text-sm">
              <span className="text-slate-400">Sort by:</span>
              <select className="bg-transparent font-bold text-slate-700 focus:outline-none cursor-pointer">
                <option>Most Popular</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Top Rated</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-2 gap-6">
            {filteredTurfs.map(turf => (
              <TurfCard key={turf.id} turf={turf} />
            ))}
          </div>

          {filteredTurfs.length === 0 && (
            <div className="text-center py-24 bg-white rounded-[3rem] border-2 border-dashed border-slate-200">
              <div className="mx-auto w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6">
                <SearchIcon size={32} className="text-slate-300" />
              </div>
              <h3 className="text-2xl font-black text-slate-800 mb-2">No Turfs Found</h3>
              <p className="text-slate-500 max-w-xs mx-auto">Try adjusting your filters or search terms to find what you're looking for.</p>
              <button 
                onClick={() => {
                  setQuery('');
                  setPriceRange(100);
                  setSelectedAmenities([]);
                }}
                className="mt-8 text-emerald-600 font-bold hover:underline"
              >
                Clear all filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const CheckIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
  </svg>
);

export default Search;
