
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { 
  Star, MapPin, ShieldCheck, Clock, Info, 
  CreditCard, Calendar as CalendarIcon, Users, Check,
  ArrowRight
} from 'lucide-react';

const TurfDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { turfs, currentUser, addBooking } = useApp();
  const navigate = useNavigate();
  const turf = turfs.find(t => t.id === id);

  const [date, setDate] = useState('2024-05-20');
  const [slot, setSlot] = useState('');
  const [isBooking, setIsBooking] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);

  if (!turf) return <div>Turf not found</div>;

  const slots = [
    '08:00 AM', '09:00 AM', '10:00 AM', '04:00 PM', '05:00 PM', '06:00 PM', '07:00 PM', '08:00 PM', '09:00 PM'
  ];

  const handleBooking = () => {
    if (!currentUser) {
      navigate('/auth');
      return;
    }
    if (!slot) return;

    setIsBooking(true);
    // Simulate API call and payment
    setTimeout(() => {
      const newBooking = {
        id: `b${Date.now()}`,
        turfId: turf.id,
        userId: currentUser.id,
        startTime: `${date} ${slot}`,
        endTime: '',
        totalPrice: turf.pricePerHour,
        status: 'confirmed' as const,
        createdAt: new Date().toISOString()
      };
      addBooking(newBooking);
      setIsBooking(false);
      setBookingSuccess(true);
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Main Info */}
        <div className="lg:col-span-2 space-y-10">
          <div className="space-y-4">
            <h1 className="text-4xl md:text-5xl font-black font-heading text-slate-900">{turf.name}</h1>
            <div className="flex flex-wrap items-center gap-6">
              <div className="flex items-center gap-2">
                <Star size={20} className="text-yellow-500 fill-yellow-500" />
                <span className="font-bold">{turf.rating}</span>
                <span className="text-slate-400 font-medium">(120+ Reviews)</span>
              </div>
              <div className="flex items-center gap-2 text-slate-500 font-medium">
                <MapPin size={20} className="text-emerald-600" />
                {turf.location}
              </div>
            </div>
          </div>

          <div className="aspect-[16/9] rounded-[2.5rem] overflow-hidden shadow-2xl">
            <img src={turf.image} alt={turf.name} className="w-full h-full object-cover" />
          </div>

          <div className="space-y-6">
            <h2 className="text-2xl font-black font-heading">About This Venue</h2>
            <p className="text-slate-600 text-lg leading-relaxed">{turf.description}</p>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {turf.amenities.map(a => (
                <div key={a} className="flex items-center gap-3 p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
                  <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
                    <Check size={16} strokeWidth={3} />
                  </div>
                  <span className="font-bold text-slate-700 text-sm">{a}</span>
                </div>
              ))}
            </div>
          </div>

          <hr className="border-slate-100" />

          {/* Rules and Regulations */}
          <div className="space-y-6">
             <h2 className="text-2xl font-black font-heading">Venue Rules</h2>
             <ul className="space-y-4">
               {[
                 'Proper football boots or sports shoes required.',
                 'No food or smoking on the pitch area.',
                 'Cancellation allowed up to 12 hours before slot.',
                 'Players should arrive 10 mins before slot.'
               ].map((rule, i) => (
                 <li key={i} className="flex items-start gap-3 text-slate-600">
                    <Info size={18} className="mt-1 text-slate-400 shrink-0" />
                    <span className="font-medium">{rule}</span>
                 </li>
               ))}
             </ul>
          </div>
        </div>

        {/* Sticky Booking Sidebar */}
        <div className="relative">
          <div className="sticky top-24 space-y-6">
            <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-2xl p-8 overflow-hidden relative">
              {bookingSuccess ? (
                <div className="text-center py-8 space-y-6">
                  <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600 mb-6">
                    <Check size={40} strokeWidth={3} />
                  </div>
                  <h3 className="text-2xl font-black text-slate-900">Booking Confirmed!</h3>
                  <p className="text-slate-500">Your slot is secured. You'll receive a confirmation email shortly.</p>
                  <button 
                    onClick={() => navigate('/dashboard')}
                    className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl hover:bg-slate-800 transition-all"
                  >
                    View in Dashboard
                  </button>
                </div>
              ) : (
                <>
                  <div className="flex justify-between items-center mb-8">
                    <div>
                      <p className="text-sm text-slate-500 font-bold uppercase tracking-wider">Starting from</p>
                      <h3 className="text-3xl font-black text-slate-900 font-heading">${turf.pricePerHour}<span className="text-lg font-bold text-slate-400">/hr</span></h3>
                    </div>
                    <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
                      <ShieldCheck size={28} />
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
                        <CalendarIcon size={16} /> Select Date
                      </label>
                      <input 
                        type="date" 
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 font-bold transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
                        <Clock size={16} /> Available Slots
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                        {slots.map(s => (
                          <button
                            key={s}
                            onClick={() => setSlot(s)}
                            className={`p-2.5 text-xs font-bold rounded-xl border transition-all ${
                              slot === s 
                              ? 'bg-emerald-600 border-emerald-600 text-white shadow-lg shadow-emerald-200' 
                              : 'bg-white border-slate-200 text-slate-600 hover:border-emerald-500 hover:text-emerald-600'
                            }`}
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-3">
                      <div className="flex justify-between text-sm font-bold text-slate-600">
                        <span>1 Hour Session</span>
                        <span>${turf.pricePerHour}.00</span>
                      </div>
                      <div className="flex justify-between text-sm font-bold text-slate-600">
                        <span>Service Fee</span>
                        <span>$2.00</span>
                      </div>
                      <hr className="border-slate-200" />
                      <div className="flex justify-between text-lg font-black text-slate-900">
                        <span>Total Price</span>
                        <span>${turf.pricePerHour + 2}.00</span>
                      </div>
                    </div>

                    <button 
                      onClick={handleBooking}
                      disabled={!slot || isBooking}
                      className={`w-full py-5 rounded-2xl font-black text-lg shadow-xl flex items-center justify-center gap-2 transition-all ${
                        !slot || isBooking 
                        ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none' 
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-200'
                      }`}
                    >
                      {isBooking ? (
                        <div className="w-6 h-6 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
                      ) : (
                        <>Confirm Booking <ArrowRight size={20} /></>
                      )}
                    </button>
                    
                    <p className="text-[10px] text-center text-slate-400 font-medium">
                      By clicking confirm, you agree to our Terms of Service and Cancellation Policy.
                    </p>
                  </div>
                </>
              )}
            </div>

            <div className="bg-emerald-50 p-6 rounded-3xl border border-emerald-100 flex gap-4 items-center">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-emerald-600 shadow-sm shrink-0">
                <CreditCard size={24} />
              </div>
              <div>
                <p className="text-sm font-black text-slate-900 mb-0.5">Secure Transaction</p>
                <p className="text-xs text-slate-500 font-medium">Encrypted SSL checkout for safe and easy payments.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TurfDetails;
