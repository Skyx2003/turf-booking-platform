
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { 
  Menu, X, Calendar, Search, User, LogOut, LayoutDashboard, Settings,
  ShieldCheck, Trophy, ChevronDown
} from 'lucide-react';

const Navbar: React.FC = () => {
  const { currentUser, logout } = useApp();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
    setShowProfileMenu(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="bg-emerald-600 p-1.5 rounded-lg text-white group-hover:bg-emerald-700 transition-colors">
                <Trophy size={24} />
              </div>
              <span className="text-2xl font-black text-slate-800 tracking-tight font-heading">
                Turf<span className="text-emerald-600">Sync</span>
              </span>
            </Link>

            <div className="hidden md:flex items-center gap-6">
              <Link to="/search" className="text-slate-600 hover:text-emerald-600 font-medium transition-colors">Find Turfs</Link>
              <Link to="/search" className="text-slate-600 hover:text-emerald-600 font-medium transition-colors">Browse Cities</Link>
              {currentUser?.role === 'ADMIN' && (
                <Link to="/dashboard" className="text-slate-600 hover:text-emerald-600 font-medium flex items-center gap-1">
                  <ShieldCheck size={16} /> Admin Panel
                </Link>
              )}
            </div>
          </div>

          <div className="hidden md:flex items-center gap-4">
            {currentUser ? (
              <div className="relative">
                <button 
                  onClick={() => setShowProfileMenu(!showProfileMenu)}
                  className="flex items-center gap-3 p-1 pl-3 pr-2 border rounded-full hover:bg-white transition-all shadow-sm"
                >
                  <span className="text-sm font-semibold text-slate-700">{currentUser.name}</span>
                  <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold">
                    {currentUser.name[0]}
                  </div>
                  <ChevronDown size={14} className={`text-slate-400 transition-transform ${showProfileMenu ? 'rotate-180' : ''}`} />
                </button>

                {showProfileMenu && (
                  <div className="absolute right-0 mt-2 w-56 rounded-xl bg-white border border-slate-200 shadow-xl overflow-hidden py-1">
                    <div className="px-4 py-2 border-b border-slate-100">
                      <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Account Role</p>
                      <p className="text-sm font-bold text-emerald-600">{currentUser.role}</p>
                    </div>
                    <Link to="/dashboard" className="flex items-center gap-3 px-4 py-2 text-sm text-slate-600 hover:bg-slate-50">
                      <LayoutDashboard size={18} /> Dashboard
                    </Link>
                    <Link to="/search" className="flex items-center gap-3 px-4 py-2 text-sm text-slate-600 hover:bg-slate-50">
                      <Search size={18} /> Find More
                    </Link>
                    <button 
                      onClick={handleLogout}
                      className="w-full flex items-center gap-3 px-4 py-2 text-sm text-red-600 hover:bg-red-50 border-t border-slate-100 mt-1"
                    >
                      <LogOut size={18} /> Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-4">
                <Link to="/auth" className="text-slate-600 hover:text-slate-900 font-semibold px-4 py-2">Sign In</Link>
                <Link to="/auth" className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-2.5 rounded-xl shadow-lg shadow-emerald-200 transition-all">
                  Get Started
                </Link>
              </div>
            )}
          </div>

          <div className="flex md:hidden items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-slate-600 p-2">
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 px-4 py-6 space-y-4">
          <Link to="/search" className="block text-lg font-semibold text-slate-700">Find Turfs</Link>
          <Link to="/dashboard" className="block text-lg font-semibold text-slate-700">My Dashboard</Link>
          <hr />
          {currentUser ? (
            <button onClick={handleLogout} className="text-red-600 font-bold">Sign Out</button>
          ) : (
            <Link to="/auth" className="block text-emerald-600 font-bold">Login / Register</Link>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
