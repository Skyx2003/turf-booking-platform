
import React from 'react';
import { Link } from 'react-router-dom';
import { Turf } from '../types';
import { Star, MapPin, ArrowRight, Tag } from 'lucide-react';

interface Props {
  turf: Turf;
}

const TurfCard: React.FC<Props> = ({ turf }) => {
  return (
    <div className="group bg-white rounded-[2rem] overflow-hidden border border-slate-100 shadow-sm hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
      <div className="relative h-60 overflow-hidden">
        <img 
          src={turf.image} 
          alt={turf.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute top-4 left-4 flex gap-2">
          <div className="bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full flex items-center gap-1.5 text-xs font-bold shadow-sm">
            <Star size={14} className="text-yellow-500 fill-yellow-500" />
            <span>{turf.rating}</span>
          </div>
          <div className="bg-emerald-600 text-white px-3 py-1.5 rounded-full text-xs font-bold shadow-sm flex items-center gap-1.5">
            <Tag size={12} />
            <span>${turf.pricePerHour}/hr</span>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-xl font-bold text-slate-900 mb-1 truncate">{turf.name}</h3>
            <div className="flex items-center gap-1.5 text-slate-500 text-sm">
              <MapPin size={14} className="shrink-0" />
              <span className="truncate">{turf.location}</span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-6">
          {turf.amenities.slice(0, 3).map((a, i) => (
            <span key={i} className="px-2.5 py-1 bg-slate-50 text-slate-600 rounded-lg text-[10px] font-bold uppercase tracking-wider">
              {a}
            </span>
          ))}
          {turf.amenities.length > 3 && (
            <span className="px-2.5 py-1 bg-slate-50 text-slate-400 rounded-lg text-[10px] font-bold">
              +{turf.amenities.length - 3} more
            </span>
          )}
        </div>

        <Link 
          to={`/turf/${turf.id}`} 
          className="w-full py-3.5 bg-slate-900 hover:bg-emerald-600 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-colors group/btn"
        >
          Book Now <ArrowRight size={18} className="group-hover/btn:translate-x-1 transition-transform" />
        </Link>
      </div>
    </div>
  );
};

export default TurfCard;
