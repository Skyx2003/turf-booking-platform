
import React from 'react';
import { Link } from 'react-router-dom';
import { Trophy, Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-slate-200 pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-8">
            <Link to="/" className="flex items-center gap-2">
              <div className="bg-emerald-600 p-1.5 rounded-lg text-white">
                <Trophy size={20} />
              </div>
              <span className="text-2xl font-black text-slate-800 tracking-tight font-heading">
                Turf<span className="text-emerald-600">Sync</span>
              </span>
            </Link>
            <p className="text-slate-500 leading-relaxed font-medium">
              Revolutionizing sports venue bookings through technology and seamless experiences.
            </p>
            <div className="flex gap-4">
              {[Facebook, Twitter, Instagram, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 hover:bg-emerald-600 hover:text-white transition-all">
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-slate-900 font-black font-heading mb-8 uppercase tracking-widest text-xs">For Players</h4>
            <ul className="space-y-4">
              <li><Link to="/search" className="text-slate-500 hover:text-emerald-600 font-medium transition-colors">Find a Turf</Link></li>
              <li><Link to="/dashboard" className="text-slate-500 hover:text-emerald-600 font-medium transition-colors">My Bookings</Link></li>
              <li><Link to="/search" className="text-slate-500 hover:text-emerald-600 font-medium transition-colors">Upcoming Tournaments</Link></li>
              <li><a href="#" className="text-slate-500 hover:text-emerald-600 font-medium transition-colors">Loyalty Program</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-slate-900 font-black font-heading mb-8 uppercase tracking-widest text-xs">For Owners</h4>
            <ul className="space-y-4">
              <li><Link to="/auth" className="text-slate-500 hover:text-emerald-600 font-medium transition-colors">List Your Facility</Link></li>
              <li><Link to="/auth" className="text-slate-500 hover:text-emerald-600 font-medium transition-colors">Pricing Plans</Link></li>
              <li><a href="#" className="text-slate-500 hover:text-emerald-600 font-medium transition-colors">Case Studies</a></li>
              <li><a href="#" className="text-slate-500 hover:text-emerald-600 font-medium transition-colors">Management Software</a></li>
            </ul>
          </div>

          <div className="bg-emerald-50 p-8 rounded-[2.5rem] border border-emerald-100">
            <h4 className="text-slate-900 font-black font-heading mb-6 uppercase tracking-widest text-xs">Support Center</h4>
            <ul className="space-y-4">
              <li className="flex items-center gap-3 text-sm font-bold text-slate-600">
                <Phone size={16} className="text-emerald-600" /> +1 (555) 800-PLAY
              </li>
              <li className="flex items-center gap-3 text-sm font-bold text-slate-600">
                <Mail size={16} className="text-emerald-600" /> support@turfsync.com
              </li>
              <li className="flex items-start gap-3 text-sm font-bold text-slate-600">
                <MapPin size={16} className="text-emerald-600 mt-0.5 shrink-0" /> 123 Arena Blvd, Sports District, CA
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4 text-sm font-bold text-slate-400">
          <p>© 2024 TurfSync. Engineered for Excellence.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-slate-900">Privacy Policy</a>
            <a href="#" className="hover:text-slate-900">Terms of Service</a>
            <a href="#" className="hover:text-slate-900">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
