
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  BarChart3, Plus, Settings, Users, Calendar, 
  MapPin, DollarSign, Trash2, Edit3, ChevronRight 
} from 'lucide-react';

const OwnerDashboard: React.FC = () => {
  const { currentUser, turfs, bookings, addTurf, deleteTurf } = useApp();
  const [showAddForm, setShowAddForm] = useState(false);

  const ownerTurfs = turfs.filter(t => t.ownerId === currentUser?.id);
  const ownerTurfIds = ownerTurfs.map(t => t.id);
  const ownerBookings = bookings.filter(b => ownerTurfIds.includes(b.turfId));

  const totalRevenue = ownerBookings.reduce((acc, curr) => acc + curr.totalPrice, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-between items-end mb-12">
        <div>
          <h1 className="text-3xl font-black text-slate-900 font-heading mb-2">Owner Console</h1>
          <p className="text-slate-500 font-medium">Welcome back, {currentUser?.name}. Manage your facilities.</p>
        </div>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-3.5 rounded-2xl flex items-center gap-2 shadow-lg shadow-emerald-200 transition-all"
        >
          <Plus size={20} /> Add New Venue
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
        {[
          { label: 'Total Venues', val: ownerTurfs.length, icon: <MapPin className="text-blue-500" /> },
          { label: 'Active Bookings', val: ownerBookings.filter(b => b.status === 'confirmed').length, icon: <Calendar className="text-emerald-500" /> },
          { label: 'Total Revenue', val: `$${totalRevenue}`, icon: <DollarSign className="text-amber-500" /> },
          { label: 'Player Count', val: new Set(ownerBookings.map(b => b.userId)).size, icon: <Users className="text-purple-500" /> },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-slate-50 rounded-2xl">{stat.icon}</div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">MTD Stats</span>
            </div>
            <p className="text-3xl font-black text-slate-900 mb-1">{stat.val}</p>
            <p className="text-sm font-bold text-slate-400">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-black font-heading">My Venues</h2>
            <button className="text-sm font-bold text-emerald-600 hover:underline">View All</button>
          </div>
          <div className="space-y-4">
            {ownerTurfs.map(turf => (
              <div key={turf.id} className="bg-white p-4 rounded-3xl border border-slate-200 flex gap-6 items-center shadow-sm">
                <img src={turf.image} className="w-24 h-24 rounded-2xl object-cover" alt="" />
                <div className="flex-grow">
                  <h3 className="text-lg font-bold text-slate-900">{turf.name}</h3>
                  <p className="text-sm text-slate-500 mb-3">{turf.location}</p>
                  <div className="flex gap-4">
                    <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">${turf.pricePerHour}/hr</span>
                    <span className="text-xs font-black text-slate-400 bg-slate-50 px-2 py-1 rounded-lg uppercase">Active</span>
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <button className="p-2.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-all">
                    <Edit3 size={18} />
                  </button>
                  <button 
                    onClick={() => deleteTurf(turf.id)}
                    className="p-2.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-black font-heading">Recent Bookings</h2>
            <button className="text-sm font-bold text-emerald-600 hover:underline">Download CSV</button>
          </div>
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100">
                  <th className="px-6 py-4 text-left text-xs font-black text-slate-400 uppercase tracking-wider">Player</th>
                  <th className="px-6 py-4 text-left text-xs font-black text-slate-400 uppercase tracking-wider">Date & Time</th>
                  <th className="px-6 py-4 text-right text-xs font-black text-slate-400 uppercase tracking-wider">Amount</th>
                  <th className="px-6 py-4"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {ownerBookings.slice(0, 5).map(booking => (
                  <tr key={booking.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-500">
                          {booking.id.slice(-2)}
                        </div>
                        <span className="text-sm font-bold text-slate-700">User_{booking.userId.slice(-4)}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <p className="text-sm font-bold text-slate-700">{booking.startTime.split(' ')[0]}</p>
                      <p className="text-xs text-slate-400">{booking.startTime.split(' ').slice(1).join(' ')}</p>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right font-black text-slate-900">
                      ${booking.totalPrice}
                    </td>
                    <td className="px-6 py-4 text-right">
                       <button className="text-slate-400 hover:text-emerald-600">
                         <ChevronRight size={18} />
                       </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {ownerBookings.length === 0 && (
              <div className="p-12 text-center text-slate-400">No bookings yet.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OwnerDashboard;
