
import React from 'react';
import { useApp } from '../context/AppContext';
import { Calendar, Clock, MapPin, CheckCircle, XCircle, ChevronRight, User as UserIcon, Mail } from 'lucide-react';
import { format } from 'date-fns';

const UserDashboard: React.FC = () => {
  const { currentUser, bookings, turfs, updateBooking } = useApp();
  
  const userBookings = bookings.filter(b => b.userId === currentUser?.id);
  const getTurf = (id: string) => turfs.find(t => t.id === id);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8 items-start mb-12">
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm w-full md:w-80 shrink-0">
          <div className="text-center space-y-4 mb-8">
            <div className="w-24 h-24 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 text-4xl font-black mx-auto shadow-inner">
              {currentUser?.name[0]}
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900 font-heading">{currentUser?.name}</h2>
              <p className="text-slate-500 flex items-center justify-center gap-1.5 font-medium">
                <Mail size={14} /> {currentUser?.email}
              </p>
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full text-xs font-bold uppercase tracking-wider">
              Verified User
            </div>
          </div>
          
          <div className="space-y-1">
            <button className="w-full flex items-center gap-3 px-4 py-3 bg-emerald-600 text-white rounded-xl font-bold transition-all shadow-lg shadow-emerald-100">
              <Calendar size={18} /> My Bookings
            </button>
            <button className="w-full flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-50 rounded-xl font-bold transition-all">
              <UserIcon size={18} /> Edit Profile
            </button>
          </div>
        </div>

        <div className="flex-grow space-y-8">
          <div>
            <h1 className="text-3xl font-black text-slate-900 font-heading mb-2">My Bookings</h1>
            <p className="text-slate-500 font-medium">Track and manage your upcoming games.</p>
          </div>

          <div className="space-y-4">
            {userBookings.length === 0 ? (
              <div className="bg-white rounded-[2rem] border-2 border-dashed border-slate-200 p-16 text-center">
                 <Calendar size={48} className="text-slate-200 mx-auto mb-6" />
                 <h3 className="text-xl font-bold text-slate-800 mb-2">No active bookings</h3>
                 <p className="text-slate-500 mb-8">Ready to play? Find an arena and start your first session.</p>
                 <a href="#/search" className="inline-flex items-center gap-2 px-8 py-4 bg-emerald-600 text-white font-bold rounded-2xl shadow-lg shadow-emerald-200">
                    Find a Turf <ChevronRight size={18} />
                 </a>
              </div>
            ) : (
              userBookings.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(booking => {
                const turf = getTurf(booking.turfId);
                return (
                  <div key={booking.id} className="bg-white rounded-3xl border border-slate-200 p-6 flex flex-col md:flex-row gap-6 items-center shadow-sm hover:shadow-md transition-shadow">
                    <img src={turf?.image} className="w-full md:w-32 h-32 rounded-2xl object-cover shrink-0" alt="" />
                    <div className="flex-grow space-y-3 w-full">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-xl font-bold text-slate-900">{turf?.name}</h3>
                          <div className="flex items-center gap-1.5 text-slate-500 text-sm">
                            <MapPin size={14} /> {turf?.location}
                          </div>
                        </div>
                        <div className={`px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-wider flex items-center gap-2 ${
                          booking.status === 'confirmed' ? 'bg-emerald-50 text-emerald-600' : 
                          booking.status === 'cancelled' ? 'bg-red-50 text-red-600' : 'bg-slate-50 text-slate-500'
                        }`}>
                          {booking.status === 'confirmed' ? <CheckCircle size={14} /> : <XCircle size={14} />}
                          {booking.status}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="flex items-center gap-2 text-slate-600 font-bold">
                          <Calendar size={16} className="text-emerald-500" />
                          {booking.startTime.split(' ')[0]}
                        </div>
                        <div className="flex items-center gap-2 text-slate-600 font-bold">
                          <Clock size={16} className="text-emerald-500" />
                          {booking.startTime.split(' ')[1]} {booking.startTime.split(' ')[2]}
                        </div>
                      </div>
                    </div>

                    <div className="flex md:flex-col gap-2 w-full md:w-fit">
                      {booking.status === 'confirmed' && (
                        <button 
                          onClick={() => updateBooking(booking.id, 'cancelled')}
                          className="flex-grow px-6 py-3 bg-red-50 hover:bg-red-100 text-red-600 font-bold rounded-xl transition-all text-sm"
                        >
                          Cancel
                        </button>
                      )}
                      <button className="flex-grow px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl transition-all text-sm">
                        View Receipt
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;
