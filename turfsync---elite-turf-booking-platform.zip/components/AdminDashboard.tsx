
import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  AreaChart, Area, Cell, PieChart, Pie 
} from 'recharts';
import { 
  ShieldCheck, Users, Activity, CreditCard, 
  AlertCircle, CheckCircle, TrendingUp, Search, Download
} from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const { turfs, bookings, users } = useApp();

  // Mock data for charts
  const bookingStats = [
    { name: 'Mon', count: 12 },
    { name: 'Tue', count: 19 },
    { name: 'Wed', count: 15 },
    { name: 'Thu', count: 22 },
    { name: 'Fri', count: 35 },
    { name: 'Sat', count: 48 },
    { name: 'Sun', count: 42 },
  ];

  const revenueData = [
    { date: '2024-05-14', revenue: 450 },
    { date: '2024-05-15', revenue: 780 },
    { date: '2024-05-16', revenue: 600 },
    { date: '2024-05-17', revenue: 1200 },
    { date: '2024-05-18', revenue: 2100 },
    { date: '2024-05-19', revenue: 1800 },
    { date: '2024-05-20', revenue: 1950 },
  ];

  const categoryData = [
    { name: 'Regular', value: 400 },
    { name: 'Premium', value: 300 },
    { name: 'Gold', value: 300 },
  ];

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b'];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-12">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <h1 className="text-3xl font-black text-slate-900 font-heading">Platform Command</h1>
            <div className="px-3 py-1 bg-slate-900 text-white text-[10px] font-black uppercase rounded-full">Admin Secure</div>
          </div>
          <p className="text-slate-500 font-medium">Real-time health and growth metrics of TurfSync ecosystem.</p>
        </div>
        <div className="flex gap-3 w-full md:w-auto">
          <div className="relative flex-grow md:w-64">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
             <input type="text" placeholder="Global search..." className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/10" />
          </div>
          <button className="p-3 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-colors shadow-sm">
            <Download size={20} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {[
          { label: 'Total Revenue', val: '$45,280', change: '+12%', icon: <TrendingUp className="text-emerald-500" /> },
          { label: 'New Signups', val: '1,284', change: '+5%', icon: <Users className="text-blue-500" /> },
          { label: 'System Load', val: '24%', change: 'Normal', icon: <Activity className="text-purple-500" /> },
          { label: 'Refund Requests', val: '12', change: 'Action Required', icon: <AlertCircle className="text-amber-500" /> },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
               {stat.icon}
            </div>
            <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">{stat.label}</p>
            <div className="flex items-end justify-between">
              <h3 className="text-3xl font-black text-slate-900">{stat.val}</h3>
              <span className={`text-xs font-bold ${stat.change.includes('+') ? 'text-emerald-600' : 'text-slate-400'}`}>
                {stat.change}
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        {/* Main Growth Chart */}
        <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm">
           <div className="flex justify-between items-center mb-10">
              <h2 className="text-xl font-black font-heading">Booking Volume</h2>
              <div className="flex gap-2">
                 {['D', 'W', 'M', 'Y'].map(t => (
                   <button key={t} className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${t === 'W' ? 'bg-slate-900 text-white' : 'hover:bg-slate-100 text-slate-400'}`}>
                     {t}
                   </button>
                 ))}
              </div>
           </div>
           <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8'}} hide />
                <Tooltip 
                  contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                />
                <Area type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={4} fillOpacity={1} fill="url(#colorRev)" />
              </AreaChart>
            </ResponsiveContainer>
           </div>
        </div>

        {/* User Types Pie */}
        <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm flex flex-col">
           <h2 className="text-xl font-black font-heading mb-8">Venue Categories</h2>
           <div className="h-60 w-full mb-8">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
           </div>
           <div className="space-y-4 flex-grow">
              {categoryData.map((d, i) => (
                <div key={d.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i] }}></div>
                    <span className="text-sm font-bold text-slate-600">{d.name}</span>
                  </div>
                  <span className="text-sm font-black text-slate-900">{d.value} units</span>
                </div>
              ))}
           </div>
        </div>
      </div>

      {/* Management Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* User Management */}
        <div className="bg-white rounded-[2.5rem] border border-slate-200 overflow-hidden shadow-sm">
           <div className="p-8 border-b border-slate-100 flex justify-between items-center">
              <h2 className="text-xl font-black font-heading">User Directory</h2>
              <button className="text-sm font-bold text-emerald-600 hover:underline">Manage All</button>
           </div>
           <div className="overflow-x-auto">
             <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <th className="px-8 py-4">Identity</th>
                    <th className="px-8 py-4">Role</th>
                    <th className="px-8 py-4">Status</th>
                    <th className="px-8 py-4">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.slice(0, 5).map(user => (
                    <tr key={user.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-8 py-5">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-black">
                            {user.name[0]}
                          </div>
                          <div>
                            <p className="text-sm font-bold text-slate-900">{user.name}</p>
                            <p className="text-xs text-slate-400">{user.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-5">
                         <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                           user.role === 'ADMIN' ? 'bg-slate-900 text-white' : 
                           user.role === 'OWNER' ? 'bg-blue-50 text-blue-600' : 'bg-emerald-50 text-emerald-600'
                         }`}>
                           {user.role}
                         </span>
                      </td>
                      <td className="px-8 py-5">
                        <div className="flex items-center gap-1.5 text-emerald-600 font-bold text-xs">
                          <CheckCircle size={14} /> Active
                        </div>
                      </td>
                      <td className="px-8 py-5">
                        <button className="text-xs font-bold text-slate-400 hover:text-slate-900">View Logs</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
             </table>
           </div>
        </div>

        {/* System Health */}
        <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white shadow-xl flex flex-col justify-between">
           <div>
              <div className="flex items-center gap-3 mb-10">
                 <div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-emerald-500/30">
                    <ShieldCheck size={28} />
                 </div>
                 <div>
                    <h2 className="text-xl font-black font-heading">Security Overview</h2>
                    <p className="text-slate-400 text-sm">Last sweep: 2 mins ago</p>
                 </div>
              </div>
              
              <div className="space-y-8">
                 {[
                   { label: 'SSL Certificate', status: 'Valid', color: 'text-emerald-500' },
                   { label: 'Database Replication', status: 'Healthy', color: 'text-emerald-500' },
                   { label: 'Payment Gateway', status: 'Online', color: 'text-emerald-500' },
                   { label: 'Cloud Storage', status: '98% Full', color: 'text-amber-500' }
                 ].map(item => (
                   <div key={item.label} className="flex items-center justify-between border-b border-white/10 pb-4">
                      <span className="font-bold text-slate-300">{item.label}</span>
                      <span className={`font-black uppercase tracking-widest text-xs ${item.color}`}>{item.status}</span>
                   </div>
                 ))}
              </div>
           </div>
           
           <div className="mt-12 bg-white/5 rounded-3xl p-6 border border-white/10">
              <p className="text-sm font-bold text-slate-400 mb-4">API Utilization (Req/min)</p>
              <div className="h-20 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={bookingStats}>
                    <Bar dataKey="count" fill="#10b981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
