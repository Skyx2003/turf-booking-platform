
export type UserRole = 'USER' | 'OWNER' | 'ADMIN';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

export type TurfStatus = 'available' | 'maintenance' | 'closed';

export interface Turf {
  id: string;
  ownerId: string;
  name: string;
  location: string;
  pricePerHour: number;
  image: string;
  rating: number;
  description: string;
  status: TurfStatus;
  amenities: string[];
}

export type BookingStatus = 'pending' | 'confirmed' | 'cancelled' | 'refunded';

export interface Booking {
  id: string;
  turfId: string;
  userId: string;
  startTime: string; // ISO string
  endTime: string; // ISO string
  totalPrice: number;
  status: BookingStatus;
  paymentId?: string;
  createdAt: string;
}

export interface AppState {
  currentUser: User | null;
  turfs: Turf[];
  bookings: Booking[];
  users: User[];
}
