
import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Turf, Booking, AppState, UserRole } from '../types';

interface AppContextType extends AppState {
  login: (email: string, role: UserRole) => void;
  logout: () => void;
  addBooking: (booking: Booking) => void;
  updateBooking: (id: string, status: Booking['status']) => void;
  addTurf: (turf: Turf) => void;
  updateTurf: (turf: Turf) => void;
  deleteTurf: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const INITIAL_TURFS: Turf[] = [
  {
    id: 't1',
    ownerId: 'owner1',
    name: 'Green Field Arena',
    location: 'Downtown Sports Complex',
    pricePerHour: 45,
    image: 'https://picsum.photos/seed/turf1/800/600',
    rating: 4.8,
    description: 'Premier floodlit artificial turf suitable for 7-a-side football and multi-sport activities.',
    status: 'available',
    amenities: ['Parking', 'Changing Rooms', 'Water', 'Floodlights']
  },
  {
    id: 't2',
    ownerId: 'owner1',
    name: 'Velocity Sports Hub',
    location: 'North Side Industrial Park',
    pricePerHour: 35,
    image: 'https://picsum.photos/seed/turf2/800/600',
    rating: 4.5,
    description: 'High-speed surface designed for competitive football and training sessions.',
    status: 'available',
    amenities: ['Parking', 'Shower', 'Canteen']
  },
  {
    id: 't3',
    ownerId: 'owner2',
    name: 'Legacy Sports Park',
    location: 'Old Town Square',
    pricePerHour: 55,
    image: 'https://picsum.photos/seed/turf3/800/600',
    rating: 4.9,
    description: 'Luxury turf with premium grass blades and spectator stand.',
    status: 'available',
    amenities: ['Spectator Stand', 'VIP Lounge', 'Floodlights', 'Cafe']
  }
];

const INITIAL_USERS: User[] = [
  { id: 'user1', name: 'John Doe', email: 'user@example.com', role: 'USER' },
  { id: 'owner1', name: 'Michael Owner', email: 'owner@example.com', role: 'OWNER' },
  { id: 'admin1', name: 'Super Admin', email: 'admin@example.com', role: 'ADMIN' }
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>(() => {
    const saved = localStorage.getItem('turfsync_state');
    if (saved) return JSON.parse(saved);
    return {
      currentUser: null,
      turfs: INITIAL_TURFS,
      bookings: [],
      users: INITIAL_USERS
    };
  });

  useEffect(() => {
    localStorage.setItem('turfsync_state', JSON.stringify(state));
  }, [state]);

  const login = (email: string, role: UserRole) => {
    const user = state.users.find(u => u.email === email && u.role === role);
    if (user) {
      setState(prev => ({ ...prev, currentUser: user }));
    } else {
      // For demo, create if not found
      const newUser: User = { id: `u${Date.now()}`, name: email.split('@')[0], email, role };
      setState(prev => ({
        ...prev,
        users: [...prev.users, newUser],
        currentUser: newUser
      }));
    }
  };

  const logout = () => {
    setState(prev => ({ ...prev, currentUser: null }));
  };

  const addBooking = (booking: Booking) => {
    setState(prev => ({ ...prev, bookings: [...prev.bookings, booking] }));
  };

  const updateBooking = (id: string, status: Booking['status']) => {
    setState(prev => ({
      ...prev,
      bookings: prev.bookings.map(b => b.id === id ? { ...b, status } : b)
    }));
  };

  const addTurf = (turf: Turf) => {
    setState(prev => ({ ...prev, turfs: [...prev.turfs, turf] }));
  };

  const updateTurf = (turf: Turf) => {
    setState(prev => ({
      ...prev,
      turfs: prev.turfs.map(t => t.id === turf.id ? turf : t)
    }));
  };

  const deleteTurf = (id: string) => {
    setState(prev => ({ ...prev, turfs: prev.turfs.filter(t => t.id !== id) }));
  };

  return (
    <AppContext.Provider value={{
      ...state,
      login,
      logout,
      addBooking,
      updateBooking,
      addTurf,
      updateTurf,
      deleteTurf
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
